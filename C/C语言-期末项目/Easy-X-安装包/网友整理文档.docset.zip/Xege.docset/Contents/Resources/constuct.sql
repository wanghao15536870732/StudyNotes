<?php
header('Content-type: text/html; charset=utf-8');
echo"<meta charset='utf-8'/>";
$dom = new DomDocument;
@$dom->loadHTMLFile("D:/dev/xexe.docset/Contents/Resources/Documents/index.html");

foreach ($dom->getElementsByTagName("a") as $a) {
	$href = $a->getAttribute("href");
	if (substr($href, 0, 1) == ".") continue;
	if (substr($href, 0, 5) == "http:") continue;

	$name = trim($a->nodeValue);
	$name = trim(preg_replace("#\s+#", "", preg_replace("#^([A-Z0-9�C]+\.)+#", "", $name)));
	if (empty($name)) continue;
	$class = "Keyword";
	$links[$name] = true;
	echo "INSERT INTO searchIndex(name, type, path) VALUES ('". $name . "','". $class ."','". $href ."');<br/>";
}
?>
